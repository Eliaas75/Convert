import React from "react";

class Convertion_CtoF extends React.Component {
  render() {
    return <h1>{this.props.temperature}</h1>;
  }
}

export default Convertion_CtoF;
